/* ===========================================================================
   ME26 AĞI - UI MOTORU (ui.js)
   Temiz, tek parça ve import güvenli final sürüm.

   Not:
   - Bu dosya başka modül import etmez.
   - Yardımcı modüller tarafından import edilebilir.
   - index.html ana giriş olarak yalnızca app.js yükler; bu dosya opsiyonel yardımcıdır.
=========================================================================== */

const $ = (id) => document.getElementById(id);

const cleanText = (value, fallback = '') => {
  if (value === null || value === undefined) return fallback;
  return String(value).trim();
};

export const escapeHtml = (value) => {
  return cleanText(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
};

const toNumber = (value, fallback = 0) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const setText = (id, value) => {
  const el = $(id);
  if (el) el.textContent = value;
};

const formatNumber = (value) => Number(value || 0).toLocaleString('tr-TR');

const emptyState = (text) => `
  <div class="text-center py-10 border border-dashed border-slate-700 rounded-2xl text-gray-500 text-xs font-bold uppercase tracking-widest bg-black/20">
    ${escapeHtml(text)}
  </div>
`;

export function showToast(message, type = 'info') {
  const container = $('toast-container');
  if (!container) {
    console.log(`[ME26 ${type}]`, message);
    return;
  }

  const variants = {
    success: 'bg-green-900/90 text-green-300 border-green-700',
    info: 'bg-blue-900/90 text-blue-300 border-blue-700',
    warning: 'bg-yellow-900/90 text-yellow-300 border-yellow-700',
    error: 'bg-red-900/90 text-red-300 border-red-700'
  };

  const icons = {
    success: '✅',
    info: 'ℹ️',
    warning: '⚠️',
    error: '❌'
  };

  const toast = document.createElement('div');
  toast.className =
    'pointer-events-auto px-4 py-3 rounded-xl border shadow-lg text-xs font-bold uppercase tracking-widest max-w-sm transition-all duration-300 ' +
    (variants[type] || variants.info);
  toast.textContent = `${icons[type] || 'ℹ️'} ${cleanText(message, 'Bildirim')}`;
  container.appendChild(toast);

  setTimeout(() => toast.classList.add('opacity-0', 'translate-y-2'), 3000);
  setTimeout(() => toast.remove(), 3500);
}

export function setLoading(buttonOrId, text = 'İşleniyor...') {
  const button = typeof buttonOrId === 'string' ? $(buttonOrId) : buttonOrId;
  if (!button) return '';
  const oldText = button.innerHTML;
  button.disabled = true;
  button.innerHTML = text;
  button.classList.add('opacity-70', 'cursor-wait');
  return oldText;
}

export function restoreButton(buttonOrId, oldText = '') {
  const button = typeof buttonOrId === 'string' ? $(buttonOrId) : buttonOrId;
  if (!button) return;
  button.disabled = false;
  if (oldText) button.innerHTML = oldText;
  button.classList.remove('opacity-70', 'cursor-wait');
}

export function showLanding() {
  $('landing-view')?.classList.remove('hidden');
  const saas = $('saas-view');
  if (saas) {
    saas.classList.add('hidden');
    saas.classList.remove('flex');
  }
  document.body.classList.remove('overflow-hidden');
}

export function showSaas() {
  $('landing-view')?.classList.add('hidden');
  const saas = $('saas-view');
  if (saas) {
    saas.classList.remove('hidden');
    saas.classList.add('flex');
  }
  document.body.classList.add('overflow-hidden');
}

export function showView(viewName) {
  if (viewName === 'saas' || viewName === 'panel') showSaas();
  else showLanding();
}

export function switchSaasTab(targetId) {
  if (!targetId) return;
  document.querySelectorAll('.view-section').forEach((section) => {
    section.classList.add('hidden');
    section.classList.remove('block');
  });

  const target = $(targetId);
  if (target) {
    target.classList.remove('hidden');
    target.classList.add('block');
  }

  document.querySelectorAll('.nav-menu-btn').forEach((button) => {
    button.classList.remove('active', 'text-white');
    button.classList.add('text-gray-400');
  });

  document.querySelectorAll(`.nav-menu-btn[data-target="${targetId}"]`).forEach((button) => {
    button.classList.add('active', 'text-white');
    button.classList.remove('text-gray-400');
  });

  document.querySelector('#saas-view main')?.scrollTo({ top: 0, behavior: 'smooth' });
}

export const switchTab = switchSaasTab;
export const navigate = switchSaasTab;

export function openModal(modalId) {
  const modal = $(modalId);
  if (!modal) return;
  modal.classList.remove('hidden');
  modal.classList.add('flex');
  modal.setAttribute('aria-hidden', 'false');
}

export function closeModal(modalId) {
  const modal = $(modalId);
  if (!modal) return;
  modal.classList.add('hidden');
  modal.classList.remove('flex');
  modal.setAttribute('aria-hidden', 'true');
}

export function closeAllModals() {
  ['ortak-kursu-modal', 'phone-modal', 'pdf-modal', 'vip-modal'].forEach(closeModal);
}

const getDigitalId = (user = {}) => {
  if (user.digitalId) return user.digitalId;
  if (user.digital_id) return user.digital_id;
  const userNo = user.vip_kurucu_no || user.kurucu_no || user.userNo || user.user_no || user.no || 'BEKLEYEN';
  return userNo && userNo !== 'BEKLEYEN' ? `TR-IA-${userNo}` : 'TR-IA-BEKLEYEN';
};

export function renderProfile(user = null) {
  const activeUser = user || window.ME26_APP?.currentUser || JSON.parse(localStorage.getItem('me26_user') || 'null') || {};
  if (!activeUser) return;

  const digitalId = getDigitalId(activeUser);
  const role = activeUser.role || activeUser.mesleki_durum || activeUser.m_durum || activeUser.rutbe || 'Kimlik Bekleniyor';
  const city = activeUser.city || activeUser.sehir || 'TRİBÜN SEÇİLMEDİ';
  const votePower = toNumber(activeUser.votePower || activeUser.vote_power || activeUser.oy_gucu, 0);
  const inviteCount = toNumber(activeUser.inviteCount || activeUser.invite_count || activeUser.davet_edilen_kisi_sayisi, 0);
  const access = votePower > 0 ? 'Tam' : 'Sınırlı';
  const inviteCode = activeUser.inviteCode || activeUser.kendi_davet_kodu || activeUser.davet_kodu || activeUser.d_kod || digitalId;
  const baseUrl = window.ME26_CONFIG?.inviteBaseUrl || window.ME26_CONFIG?.officialBaseUrl || 'https://me26.mustafaerciyas.workers.dev';
  const inviteLink = `${String(baseUrl).replace(/\/+$/, '')}/?ref=${encodeURIComponent(inviteCode)}`;

  setText('sidebar-user-id', digitalId);
  setText('mobile-user-id', digitalId);
  setText('ui-user-id', digitalId);
  setText('ui-user-role', role);
  setText('sidebar-user-role', role);
  setText('ui-user-city', city);
  setText('ui-vote-power', access);
  setText('sidebar-vote-power', `Erişim Seviyesi ${access}`);
  setText('ui-invite-link', inviteLink);
  setText('ui-vip-invite-count', `${inviteCount} / 3 Paylaşım`);

  const progressBar = $('ui-vip-progress-bar');
  if (progressBar) progressBar.style.width = `${Math.min((inviteCount / 3) * 100, 100)}%`;

  const cityGate = $('ui-city-selector-container');
  if (cityGate) {
    const hasCity = Boolean(city && city !== 'Belirsiz' && city !== 'TRİBÜN SEÇİLMEDİ');
    cityGate.classList.toggle('hidden', hasCity);
  }

  const roleBadge = $('ui-role-badge');
  if (roleBadge) {
    if (activeUser.isVip || activeUser.is_vip) {
      roleBadge.textContent = 'VIP KURUCU';
      roleBadge.className = 'inline-flex bg-kaos text-slate-950 border border-kaos px-2 py-1 rounded text-[8px] font-black uppercase tracking-widest mb-4';
    } else if (digitalId !== 'TR-IA-BEKLEYEN') {
      roleBadge.textContent = 'ASİL KURUCU';
      roleBadge.className = 'inline-flex bg-blue-500/20 text-blue-400 border border-blue-500/30 px-2 py-1 rounded text-[8px] font-bold uppercase tracking-widest mb-4';
    } else {
      roleBadge.textContent = 'ME26 Ağı Onay Bekliyor';
      roleBadge.className = 'inline-flex bg-yellow-500/20 text-yellow-500 border border-yellow-500/30 px-2 py-1 rounded text-[8px] font-bold uppercase tracking-widest mb-4';
    }
  }
}

export const renderUser = renderProfile;
export const updateUserPanel = renderProfile;
export const renderUserInfo = renderProfile;

export function renderProposalCard(item = {}, options = {}) {
  const destekSayisi = toNumber(item.destek_sayisi || item.destekSayisi || item.support_count, 0);
  const status = cleanText(item.status || item.durum).toLowerCase();
  const isAgenda = options.isAgenda || destekSayisi >= 50 || ['gundem', 'gündem', 'voting', 'oylama'].includes(status);
  const title = item.baslik || item.title || 'Başlıksız Önerge';
  const problem = item.sorun || item.problem || item.aciklama || 'Açıklama yok.';
  const solution = item.cozum || item.solution || '';

  return `
    <div class="bg-black/50 border border-slate-800 p-5 rounded-2xl shadow-lg">
      <div class="text-[9px] font-black uppercase tracking-widest text-kaos mb-3">${isAgenda ? 'Gündemde' : 'Destek Bekliyor'}</div>
      <h3 class="text-lg md:text-xl font-black text-white mb-2 leading-tight">${escapeHtml(title)}</h3>
      <p class="text-xs md:text-sm text-gray-400 leading-relaxed mb-4">${escapeHtml(problem)}</p>
      ${solution ? `<p class="text-xs md:text-sm text-gray-500 leading-relaxed mb-4">${escapeHtml(solution)}</p>` : ''}
      <div class="flex items-center justify-between gap-3">
        <span class="text-[10px] text-gray-500 font-black uppercase tracking-widest">Destek: ${destekSayisi}/50</span>
        <button type="button" data-id="${escapeHtml(item.id || '')}" class="btn-destekle bg-slate-800 border border-slate-600 hover:border-kaos hover:text-kaos text-white rounded-xl px-5 py-3 text-[10px] font-black uppercase tracking-widest transition">Destekle</button>
      </div>
    </div>`;
}

export function renderProposals(list = []) {
  const container = $('proposals-container');
  if (!container) return;
  const items = Array.isArray(list) ? list : [];
  container.innerHTML = items.length ? items.map((item) => renderProposalCard(item)).join('') : emptyState('Henüz önerge yok.');
}

export function renderGundem(list = []) {
  const container = $('gundem-container');
  if (!container) return;
  const items = Array.isArray(list) ? list : [];
  container.innerHTML = items.length ? items.map((item) => renderProposalCard(item, { isAgenda: true })).join('') : emptyState('Henüz gündem yok.');
}

export const renderOnergeler = renderProposals;
export const onergeleriCiz = renderProposals;

export function renderQuestionCard(item = {}) {
  const title = item.baslik || item.title || 'Başlıksız Soru';
  const content = item.icerik || item.content || item.aciklama || '';
  const author = item.yazar_dijital_id || item.author_id || item.yazar || 'TR-IA-BEKLEYEN';
  const solved = Boolean(item.cozuldu_mu || item.solved);
  return `
    <div class="bg-black/50 border border-slate-800 p-5 rounded-2xl shadow-lg">
      <div class="flex items-center justify-between text-[9px] uppercase tracking-widest mb-3">
        <span class="text-kaos font-black">${solved ? 'Kütüphane' : 'Çözüm Bekliyor'}</span>
        <span class="text-gray-500 font-mono">${escapeHtml(author)}</span>
      </div>
      <h3 class="text-lg font-black text-white mb-2">${escapeHtml(title)}</h3>
      <p class="text-xs md:text-sm text-gray-400 leading-relaxed">${escapeHtml(content)}</p>
    </div>`;
}

export function renderQuestions(list = []) {
  const container = $('qa-listesi');
  if (!container) return;
  const items = Array.isArray(list) ? list : [];
  container.innerHTML = items.length ? items.map((item) => renderQuestionCard(item)).join('') : emptyState('Henüz soru yok.');
}

export const renderQAList = renderQuestions;
export const sorulariCiz = renderQuestions;

export function renderTribunLigi(list = []) {
  const body = $('tribun-ligi-body');
  if (!body) return;
  const items = Array.isArray(list) ? list : [];
  if (!items.length) {
    body.innerHTML = '<tr><td colspan="2" class="p-4 text-center text-gray-500 text-xs uppercase tracking-widest">Henüz tribün verisi yok.</td></tr>';
    return;
  }
  body.innerHTML = items.map((item, index) => {
    const city = item.sehir || item.city || item.name || item.il || 'Belirsiz';
    const power = item.guc || item.güç || item.power || item.puan || 0;
    return `<tr class="border-b border-slate-800"><td class="p-4 font-black text-white text-sm">${index + 1}. ${escapeHtml(city)}</td><td class="p-4 font-mono font-black text-kaos text-sm text-right">${formatNumber(power)}</td></tr>`;
  }).join('');
}

export function renderStadiumStats(stats = {}) {
  setText('stat-total-online', formatNumber(stats.total || stats.total_online || 0));
  setText('stat-mezun-online', formatNumber(stats.mezun || stats.mezun_online || 0));
  setText('stat-ogrenci-online', formatNumber(stats.ogrenci || stats.ogrenci_online || 0));
  setText('stat-lider-tribun', stats.lider || stats.lider_tribun || 'Bekleniyor');
}

export function renderStadiumTribunes(list = []) {
  const container = $('stadyum-tribunler');
  if (!container) return;
  const items = Array.isArray(list) ? list : [];
  container.innerHTML = items.length
    ? items.map((item) => `<div class="bg-slate-900/80 border border-slate-800 rounded-xl p-3"><div class="text-[10px] text-gray-500 uppercase tracking-widest">${escapeHtml(item.sehir || item.city || item.name || 'Belirsiz')}</div><div class="text-xl font-black text-kaos">${formatNumber(item.count || item.sayi || item.online || 0)}</div></div>`).join('')
    : '<div class="text-xs text-gray-500 uppercase tracking-widest">Tribünler hazırlanıyor...</div>';
}

export function addStadiumMessage(message = {}) {
  const container = $('stadyum-chat-messages');
  if (!container) return;
  const row = document.createElement('div');
  row.className = 'bg-slate-900/70 border border-slate-800 rounded-xl px-3 py-2 text-xs';
  row.innerHTML = `<div class="text-[9px] text-kaos font-black uppercase tracking-widest">${escapeHtml(message.author || message.yazar || message.id || 'TR-IA')} ${escapeHtml(message.city || message.sehir || '')}</div><div class="text-gray-300 mt-1">${escapeHtml(message.text || message.mesaj || message.content || '')}</div>`;
  container.appendChild(row);
  container.scrollTop = container.scrollHeight;
}

export function renderStageSpeaker(speaker = null) {
  setText('sahne-kisi-isim', speaker ? speaker.name || speaker.id || 'TR-IA' : 'Saha Boş');
  setText('sahne-kisi-rol', speaker ? speaker.role || speaker.rol || 'Kürsüde' : 'Kimse Konuşmuyor');
  const icon = $('sahne-mic-icon');
  if (icon) icon.className = speaker ? 'fa-solid fa-microphone text-3xl text-kaos' : 'fa-solid fa-microphone-slash text-3xl text-gray-600';
}

export function clearInputs(ids = []) {
  ids.forEach((id) => {
    const el = $(id);
    if (!el) return;
    if (el.type === 'checkbox' || el.type === 'radio') el.checked = false;
    else el.value = '';
  });
}

export function getInputValue(id, fallback = '') {
  return cleanText($(id)?.value, fallback);
}

export function setInputValue(id, value = '') {
  const el = $(id);
  if (el) el.value = value;
}

export function triggerVerificationGate(silent = false) {
  const user = window.ME26_APP?.currentUser || JSON.parse(localStorage.getItem('me26_user') || 'null') || null;
  const verified = Boolean(user && (Number(user.votePower || user.oy_gucu || 0) > 0 || user.documentStatus === 'Onaylandı'));
  if (!verified && !silent) {
    showToast('Bu alan için telefon ve belge doğrulaması gerekiyor.', 'warning');
    switchSaasTab('view-profil');
  }
  return verified;
}

export function initUI() {
  document.querySelectorAll('[data-close-modal]').forEach((button) => {
    if (button.dataset.me26CloseBound === '1') return;
    button.dataset.me26CloseBound = '1';
    button.addEventListener('click', () => {
      const target = button.getAttribute('data-close-modal');
      if (target) closeModal(target);
    });
  });

  document.querySelectorAll('.nav-menu-btn').forEach((button) => {
    if (button.dataset.me26UiNavBound === '1') return;
    button.dataset.me26UiNavBound = '1';
    button.addEventListener('click', () => {
      const target = button.getAttribute('data-target');
      if (target) switchSaasTab(target);
    });
  });

  if (!window.__ME26_UI_ESC_BOUND__) {
    window.__ME26_UI_ESC_BOUND__ = true;
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closeAllModals();
    });
  }
}

export const UI = {
  escapeHtml,
  showToast,
  toast: showToast,
  setLoading,
  restoreButton,
  showLanding,
  showSaas,
  showView,
  switchSaasTab,
  switchTab,
  navigate,
  openModal,
  closeModal,
  closeAllModals,
  renderProfile,
  renderUser,
  updateUserPanel,
  renderUserInfo,
  renderProposalCard,
  renderProposals,
  renderGundem,
  renderOnergeler,
  onergeleriCiz,
  renderQuestionCard,
  renderQuestions,
  renderQAList,
  sorulariCiz,
  renderTribunLigi,
  renderStadiumStats,
  renderStadiumTribunes,
  addStadiumMessage,
  renderStageSpeaker,
  clearInputs,
  getInputValue,
  setInputValue,
  triggerVerificationGate,
  initUI
};

window.UI = { ...(window.UI || {}), ...UI };

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initUI);
else initUI();

console.info('ME26 ui.js temiz final sürüm yüklendi.');

# ME26.io Düzeltme ve Hata Raporu

Bu ZIP, GitHub ana dizinindeki ME26 dosya yapısına göre temizlenmiş canlı test paketidir.

## Düzeltilen kritik hatalar

1. `index.html` sonunda yarım kalan acil fallback script kaldırıldı.
   - Eski dosya `const { data: createdUser, error:` satırında kesiliyordu.
   - Yeni dosyada `</body>` ve `</html>` kapanışları sağlam.

2. `index.html` içinde ana motor bağlantısı sadeleştirildi.
   - Sadece şu giriş kullanılıyor: `<script type="module" src="./app.js"></script>`
   - Çift Firebase/Supabase başlatma riski kaldırıldı.

3. `style.css` index'e bağlandı.
   - `<link rel="stylesheet" href="./style.css" />` eklendi.

4. `ui.js` komple temiz tek parça olarak yeniden yazıldı.
   - Eski çift import / iki dosya üst üste yapışma sorunu kaldırıldı.
   - `escapeHtml` güvenli hale getirildi.
   - `UI.triggerVerificationGate()` eklendi; `qa.js` ile uyum korundu.
   - `UI.renderProfile()`, modal, toast, tab geçişleri ve render yardımcıları korundu.

5. `app.js` kullanıcı oluşturma akışı güçlendirildi.
   - `me26_sistem_giris` RPC çalışmazsa `users` tablosuna fallback `upsert` denenir.
   - Girişteki çift `saveLocalUser()` temizlendi.
   - Eski “diğer modüller bozuk” yorumu kaldırıldı.

6. Eksik buton bağlantıları eklendi.
   - `btn-open-proposal-modal-2`
   - `btn-open-koruma-form`
   - `btn-koruma-form-ac`
   - `btn-koruma-bildirim-olustur`
   - `btn-whatsapp-share`
   - `btn-standart-numara`
   - `btn-claim-vip-number`
   - `btn-kursuyu-birak`

7. Eski Vercel fallback adresleri temizlendi.
   - Yardımcı dosyalarda fallback adres Cloudflare Workers adresine çekildi.

## Korunan yapı

- `app.js` ana canlı motor olarak bırakıldı.
- `auth.js`, `supabase.js`, `state.js`, `qa.js`, `stadium.js`, `koruma.js`, `vip.js` dosyaları korunup syntax açısından kontrol edildi.
- `favicon.png` aynen korundu.
- `wrangler.jsonc` Cloudflare static assets yapısına uygun bırakıldı.

## Canlıya atmadan önce yapılacak hızlı test

1. GitHub'a ZIP içindeki dosyaları yükle.
2. Cloudflare/GitHub Pages cache temizse sayfayı yenile.
3. Chrome DevTools > Console aç.
4. Şunları test et:
   - Google ile giriş
   - Çıkış
   - Şehir kaydetme
   - Önerge gönderme
   - Destekle butonu
   - Koruma hattı gönderimi
   - Davet linki kopyalama
   - WhatsApp paylaşımı

## Hâlâ dış sistemde kontrol edilmesi gerekenler

- Firebase Authentication > Authorized domains alanına canlı domain ekli olmalı.
- Supabase RLS politikaları frontend anon key ile uyumlu olmalı.
- `me26_sistem_giris`, `me26_onerge_gonder`, `me26_destek_ver`, `me26_tribun_ligi_getir` RPC fonksiyonları Supabase'de gerçekten tanımlı olmalı.
- GitHub repo About linki hâlâ Vercel gösteriyorsa GitHub arayüzünden Cloudflare Workers adresiyle değiştirilmeli.

## Önerilen yeni puan

Bu paket, eski ZIP'teki 64/100 seviyesinden teknik olarak yaklaşık 76/100 bandına çıkarılmıştır. Gerçek puan, canlı tarayıcı console testinden sonra netleşir.

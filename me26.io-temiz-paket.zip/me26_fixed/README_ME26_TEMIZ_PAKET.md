# ME26.io Temiz Canlı Paket

Ana giriş dosyası: `index.html`  
Ana JavaScript motoru: `app.js`  
Yayın hedefi: Cloudflare Workers / Static Assets

## Yükleme

Bu klasördeki tüm dosyaları GitHub repo ana dizinine yükleyin. Eski dosyaların üzerine yazın.

## Önemli

- `index.html` yalnızca `app.js` yükler.
- `app.js` Google giriş, Supabase kayıt, panel geçişi, önerge, destek, tribün ve koruma hattı temel akışlarını taşır.
- `ui.js` artık temiz ve import edilebilir yardımcı modüldür.
- Service role key veya gizli admin anahtarı bu pakette yoktur; sadece public/anon frontend key kullanılmaktadır.
